import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ParseDataService {
  flag: boolean = true;
  constructor() {
  }
  ParseNames(usersData) {
    if (this.flag === true) {
      usersData.sort((name1, name2) => {
        if (name1.name.split(' ')[1] < name2.name.split(' ')[1]) {
          return -1;
        } else if (name1.name.split(' ')[1] > name2.name.split(' ')[1]) {
          return 1;
        } else {
          return 0;
        }
      });
      this.flag = false;
      return usersData;
    } else {
      usersData.sort((name1, name2) => {
        if (name1.name.split(' ')[1] > name2.name.split(' ')[1]) {
          return -1;
        } else if (name1.name.split(' ')[1] < name2.name.split(' ')[1]) {
          return 1;
        } else {
          return 0;
        }
      });
      this.flag = true;
      return usersData;
    }
  }
}
