import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class FetchDataService {

  constructor(private http: HttpClient) { }
  getData(): any {
    return this.http.get("https://jsonplaceholder.typicode.com/users")
  }
}
