import { Component, OnInit } from '@angular/core';
import { FetchDataService } from './fetch-data.service';
import { ParseDataService } from './parse-data.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  users: any;
  constructor(private _fetchData: FetchDataService, private _sortData: ParseDataService) {
  }

  ngOnInit() {
    this._fetchData.getData()
      .subscribe((data) => {
        this.users = data.filter(function (curr) {
          return curr.phone.includes('x') == false;
        });
      });
  }
  sortFullname() {
    this.users = this._sortData.ParseNames(this.users);
  }

}
