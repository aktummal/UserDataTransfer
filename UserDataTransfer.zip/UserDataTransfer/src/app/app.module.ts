import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { FetchDataService } from './fetch-data.service';
import { ParseDataService } from './parse-data.service';


@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
  ],
  providers: [FetchDataService,ParseDataService],
  bootstrap: [AppComponent]
})
export class AppModule { }
